create function col_description(oid, integer) returns text
    stable
    strict
    parallel safe
    language sql
as
$$select description from pg_catalog.pg_description where objoid = $1 and classoid = 'pg_catalog.pg_class'::pg_catalog.regclass and objsubid = $2$$;

comment on function col_description(oid, integer) is 'get description for table column';

alter function col_description(oid, integer) owner to postgres;

