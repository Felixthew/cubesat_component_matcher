create view pg_file_settings (sourcefile, sourceline, seqno, name, setting, applied, error) as
SELECT a.sourcefile,
       a.sourceline,
       a.seqno,
       a.name,
       a.setting,
       a.applied,
       a.error
FROM pg_show_all_file_settings() a(sourcefile, sourceline, seqno, name, setting, applied, error);

alter table pg_file_settings
    owner to postgres;

