create function obj_description(oid) returns text
    stable
    strict
    parallel safe
    language sql
as
$$select description from pg_catalog.pg_description where objoid = $1 and objsubid = 0$$;

comment on function obj_description(oid, name) is 'deprecated, use two-argument form instead';

alter function obj_description(oid, name) owner to postgres;

