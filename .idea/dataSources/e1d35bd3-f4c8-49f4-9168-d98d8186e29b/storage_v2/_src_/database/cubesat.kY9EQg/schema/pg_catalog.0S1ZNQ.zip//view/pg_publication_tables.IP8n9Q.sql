create view pg_publication_tables(pubname, schemaname, tablename) as
SELECT p.pubname,
       n.nspname AS schemaname,
       c.relname AS tablename
FROM pg_publication p,
     LATERAL pg_get_publication_tables(p.pubname::text) gpt(relid),
     pg_class c
         JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE c.oid = gpt.relid;

alter table pg_publication_tables
    owner to postgres;

grant select on pg_publication_tables to public;

