create function shobj_description(oid, name) returns text
    stable
    strict
    parallel safe
    language sql
as
$$select description from pg_catalog.pg_shdescription where objoid = $1 and classoid = (select oid from pg_catalog.pg_class where relname = $2 and relnamespace = 11)$$;

comment on function shobj_description(oid, name) is 'get description for object id and shared catalog name';

alter function shobj_description(oid, name) owner to postgres;

